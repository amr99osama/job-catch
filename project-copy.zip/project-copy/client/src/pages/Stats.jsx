const Stats = () => {
  return <div>Stats</div>;
};

export default Stats;
