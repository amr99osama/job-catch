const DeleteJob = () => {
  return <div>DeleteJob</div>;
};

export default DeleteJob;
