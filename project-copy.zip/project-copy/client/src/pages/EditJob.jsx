const EditJob = () => {
  return <div>EditJob</div>;
};

export default EditJob;
