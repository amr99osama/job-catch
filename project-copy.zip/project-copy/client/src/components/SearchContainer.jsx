const SearchContainer = () => {
  return <h3>Search Container</h3>;
};
export default SearchContainer;
