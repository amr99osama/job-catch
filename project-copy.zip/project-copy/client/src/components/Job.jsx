const Job = () => {
  return <h3>Single Job</h3>;
};
export default Job;
