import mainlogo from "../assets/images/logo.svg";
const Logo = () => {
  return <img src={mainlogo} alt="job-catch" className="logo" />;
};
export default Logo;
